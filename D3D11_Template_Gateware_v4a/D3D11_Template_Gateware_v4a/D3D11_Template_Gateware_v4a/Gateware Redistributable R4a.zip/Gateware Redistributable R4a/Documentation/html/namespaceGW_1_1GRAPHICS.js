var namespaceGW_1_1GRAPHICS =
[
    [ "GDirectX11Surface", "classGW_1_1GRAPHICS_1_1GDirectX11Surface.html", "classGW_1_1GRAPHICS_1_1GDirectX11Surface" ],
    [ "GOpenGLSurface", "classGW_1_1GRAPHICS_1_1GOpenGLSurface.html", "classGW_1_1GRAPHICS_1_1GOpenGLSurface" ]
];