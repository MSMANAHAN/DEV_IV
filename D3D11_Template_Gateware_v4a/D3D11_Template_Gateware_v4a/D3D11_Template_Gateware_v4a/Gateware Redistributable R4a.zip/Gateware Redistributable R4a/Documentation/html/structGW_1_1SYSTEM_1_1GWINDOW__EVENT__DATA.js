var structGW_1_1SYSTEM_1_1GWINDOW__EVENT__DATA =
[
    [ "eventFlags", "structGW_1_1SYSTEM_1_1GWINDOW__EVENT__DATA.html#a9a3463e7fe90f6c9cb4c4f7d68f62ee1", null ],
    [ "height", "structGW_1_1SYSTEM_1_1GWINDOW__EVENT__DATA.html#a1bd478c20e20d67fcef4278888f29225", null ],
    [ "width", "structGW_1_1SYSTEM_1_1GWINDOW__EVENT__DATA.html#aedd64cb9564e161fc24a9ea597576dc9", null ],
    [ "windowHandle", "structGW_1_1SYSTEM_1_1GWINDOW__EVENT__DATA.html#a08f52d27570c3cad613dd19fe72a88ac", null ],
    [ "windowX", "structGW_1_1SYSTEM_1_1GWINDOW__EVENT__DATA.html#acb671b49c59e58b84d797e5c3ac6deaf", null ],
    [ "windowY", "structGW_1_1SYSTEM_1_1GWINDOW__EVENT__DATA.html#aaf455dc933271e4ba81225b8b0433ebc", null ]
];