var structGW_1_1MATH_1_1GVECTORF =
[
    [ "data", "structGW_1_1MATH_1_1GVECTORF.html#a19527bde37e35d30b7deb8568794c267", null ],
    [ "w", "structGW_1_1MATH_1_1GVECTORF.html#ac0d112f2d6b83e49541ebbf259a97320", null ],
    [ "x", "structGW_1_1MATH_1_1GVECTORF.html#a1e58106098cee18ccca5a8ae2458086f", null ],
    [ "y", "structGW_1_1MATH_1_1GVECTORF.html#a1b069fc0c18416c93463bc5da8e52c44", null ],
    [ "z", "structGW_1_1MATH_1_1GVECTORF.html#aa323ff25f2fe2bc2a4dd7c7ce3c00394", null ]
];