var classGW_1_1GRAPHICS_1_1GOpenGLSurface =
[
    [ "EnableSwapControl", "classGW_1_1GRAPHICS_1_1GOpenGLSurface.html#a1a4d3e9f9e183a4987bf13187d802e66", null ],
    [ "GetAspectRatio", "classGW_1_1GRAPHICS_1_1GOpenGLSurface.html#ad660a6eed3ca53cc7eab24ae855b6572", null ],
    [ "GetContext", "classGW_1_1GRAPHICS_1_1GOpenGLSurface.html#acc0962496aab996bddae1b84a5d178b9", null ],
    [ "QueryExtensionFunction", "classGW_1_1GRAPHICS_1_1GOpenGLSurface.html#a045548083dbdd547b18ef9b9a896f0de", null ],
    [ "UniversalSwapBuffers", "classGW_1_1GRAPHICS_1_1GOpenGLSurface.html#a6a7fda7ba935e9fc22cd94ac47ebe886", null ]
];