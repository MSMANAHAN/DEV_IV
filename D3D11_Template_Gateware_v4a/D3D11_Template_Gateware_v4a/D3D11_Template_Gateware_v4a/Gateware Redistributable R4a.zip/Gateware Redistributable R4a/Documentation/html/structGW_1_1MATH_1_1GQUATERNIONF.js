var structGW_1_1MATH_1_1GQUATERNIONF =
[
    [ "data", "structGW_1_1MATH_1_1GQUATERNIONF.html#a13306af7f2f7c2036f4fe9f275eb6d93", null ],
    [ "w", "structGW_1_1MATH_1_1GQUATERNIONF.html#a54b4529321f6a82f01406466a5fe1f2d", null ],
    [ "x", "structGW_1_1MATH_1_1GQUATERNIONF.html#aeafc0c7c427d178d46feb1809966b7ba", null ],
    [ "y", "structGW_1_1MATH_1_1GQUATERNIONF.html#a9ccf1c11c547b434fb92c99f3366700c", null ],
    [ "z", "structGW_1_1MATH_1_1GQUATERNIONF.html#a1b1e0bf8cef890cdff4cf78f634ba5e2", null ]
];