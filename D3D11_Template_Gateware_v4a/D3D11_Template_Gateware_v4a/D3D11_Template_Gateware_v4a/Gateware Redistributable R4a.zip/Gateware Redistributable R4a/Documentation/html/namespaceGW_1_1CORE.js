var namespaceGW_1_1CORE =
[
    [ "GBroadcasting", "classGW_1_1CORE_1_1GBroadcasting.html", "classGW_1_1CORE_1_1GBroadcasting" ],
    [ "GInterface", "classGW_1_1CORE_1_1GInterface.html", "classGW_1_1CORE_1_1GInterface" ],
    [ "GListener", "classGW_1_1CORE_1_1GListener.html", "classGW_1_1CORE_1_1GListener" ],
    [ "GMultiThreaded", "classGW_1_1CORE_1_1GMultiThreaded.html", null ],
    [ "GSingleThreaded", "classGW_1_1CORE_1_1GSingleThreaded.html", null ]
];