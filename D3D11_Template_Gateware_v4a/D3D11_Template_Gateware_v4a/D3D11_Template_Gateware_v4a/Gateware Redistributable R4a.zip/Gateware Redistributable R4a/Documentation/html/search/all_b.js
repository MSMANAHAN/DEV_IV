var searchData=
[
  ['normalized',['NormalizeD',['../classGW_1_1MATH_1_1GQuaternion.html#aee972e9eadcb9656153e3a6b218e5aa9',1,'GW::MATH::GQuaternion::NormalizeD()'],['../classGW_1_1MATH_1_1GVector.html#a0f950e0db160053011d6aa0b5cf3159d',1,'GW::MATH::GVector::NormalizeD()']]],
  ['normalizef',['NormalizeF',['../classGW_1_1MATH_1_1GQuaternion.html#ac1f96d734beba721fdfbc2e5cfb72cd2',1,'GW::MATH::GQuaternion::NormalizeF()'],['../classGW_1_1MATH_1_1GVector.html#a736e7cf06c1226df11c092e67f0689ab',1,'GW::MATH::GVector::NormalizeF()']]]
];
